# README #

This README would normally document whatever steps are necessary to get your application up and running.

### ToDo ###

* Add MySql through Amazon Web Services.
* Implement UI to select several parks an specify several commands. 

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Install Node js
* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
	Change current folder to the root path of the project and run "node server" in terminal.
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact